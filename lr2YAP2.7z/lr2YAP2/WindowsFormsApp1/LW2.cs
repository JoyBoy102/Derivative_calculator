﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text.RegularExpressions;

namespace App
{
    public class Derivative
    {
        public string diff;
        protected List<string> operators;
        public Derivative(string expression)
        {
            Expression expr = new Expression(expression, 1);
            operators = new List<string> { "+", "-", "(", "*", "/", "^", "sin", "cos", "~", "ln"};
            diff = get_diff(getTree(expr));
            //while (check_mult(diff))
            //diff = format_expr(diff);
            //diff = diff.Replace("+-", "-")
                       //.Replace("-+", "-")
                       //.Replace("--", "+")
                       //.Replace("~", "-");
        }

        public Node getTree(Expression expr)
        {
            Stack<Node> stack = new Stack<Node>();
            List<string> postfixExp = expr.postfix_expr_ver1;
            foreach (string elem in postfixExp)
            {
                if (!operators.Contains(elem))
                {
                    stack.Push(new Node(elem));
                }
                else
                {
                    Node node = new Node(elem);
                    if (elem == "sin" || elem == "cos" || elem == "~" || elem == "ln")
                    {
                        if (stack.Count != 0)
                            node.assign_links(null, stack.Pop());

                    }
                    else
                        node.assign_links(stack.Pop(), stack.Pop());
                    stack.Push(node);
                }
            }
            return stack.Pop();
        }

        public string get_diff(Node node)
        {
            string diff1;
            string diff2;
            if (!node.get_expr().Contains("x"))
                return "0";
            switch (node.elem)
            {
                case "x":
                    return "1";
                   
                case "*":
                    
                    diff1 = get_diff(node.firstNode);
                    diff2 = get_diff(node.secondNode);
                    if (diff1 == "0" && diff2 != "0")
                    {
                        if (diff2 != "1")
                            return $"{diff2}*{node.firstNode.get_expr()}";
                        else
                            return node.firstNode.get_expr();
                    }
                    else if (diff1 != "0" && diff2 == "0")
                    {
                        if (diff1 != "1")
                            return $"{diff1}*{node.secondNode.get_expr()}";
                        else
                            return node.secondNode.get_expr();
                    }
                    else if (diff1 != "0" && diff2 != "0")
                    {
                        if (diff1 != "1" && diff2 != "1")
                            return $"(({diff1}*{node.secondNode.get_expr()})+({diff2}*{node.firstNode.get_expr()}))";
                        else if (diff1 == "1" && diff2 != "1")
                            return $"({node.secondNode.get_expr()}+({diff2}*{node.firstNode.get_expr()}))";
                        else if (diff1 != "1" && diff2 == "1")
                            return $"({node.firstNode.get_expr()}+({diff1}*{node.secondNode.get_expr()}))";
                        else return $"({node.secondNode.get_expr()}+{node.firstNode.get_expr()})";

                    }
                    else return "0";
                    
                case "^":
                    diff1 = get_diff(node.firstNode);
                    diff2 = get_diff(node.secondNode);
                    Expression expr = new Expression("0", 1);
                    double number = 0;
                    bool isNum;
                    try
                    {
                        isNum = double.TryParse(expr.calculate(node.secondNode.get_expr()), out number);
                    }
                    catch
                    {
                        isNum = false;
                    }
                    if (isNum)
                    {
                        
                        if (number == 1)
                            return get_diff(node.firstNode);
                        if (diff1 != "1")
                        {
                            if (number > 2)
                                return $"{diff1}*{number}*{node.firstNode.get_expr()}^{number - 1}";
                            else
                            {
                                if (number != 0)
                                    return $"{diff1}*{number}*{node.firstNode.get_expr()}";
                                else
                                    return "0";

                            }
                                
                        }
                        else
                        {
                            if (number > 2 || number < 1)
                                return $"{number}*{node.firstNode.get_expr()}^{number - 1}";
                            else
                            {
                                if (number != 0)
                                    return $"{number}*{node.firstNode.get_expr()}";
                                else
                                    return "0";
                            }
                        }


                    }
                    else if (double.TryParse(node.firstNode.elem, out double res2) || node.firstNode.elem == "e")
                    {
                        string ss = node.get_expr();
                        string sss = node.firstNode.get_expr();
                        return $"{diff2}*{ss}*ln{sss}";
                    }
                    else
                    {
                        string new_exp = $"e^({node.secondNode.get_expr()}*ln(x))";
                        Expression new_expr = new Expression(new_exp, 1);
                        return get_diff(getTree(new_expr));
                    }
                    
                case "+":
                    diff1 = get_diff(node.firstNode);
                    diff2 = get_diff(node.secondNode);
                    if (diff1 != "0" && diff2 != "0")
                        return $"({diff1}+{diff2})";
                    else if (diff1 != "0" && diff2 == "0")
                        return $"{diff1}";
                    else if (diff1 == "0" && diff2 != "0")
                        return $"{diff2}";
                    else return "0";
                    
                    
                case "-":
                    diff1 = get_diff(node.firstNode);
                    diff2 = get_diff(node.secondNode);
                    if (diff1 != "0" && diff2 != "0")
                        return $"({diff1}-{diff2})";
                    else if (diff1 != "0" && diff2 == "0")
                        return $"{diff1}";
                    else if (diff1 == "0" && diff2 != "0")
                        return $"{diff2}";
                    else return "0";
                case "/":
                    diff1 = get_diff(node.firstNode);
                    diff2 = get_diff(node.secondNode);
                    if (node.firstNode.get_expr() == node.secondNode.get_expr())
                        return "0";
                    string numerator ="1";
                    if (diff1 == "0" && diff2 != "0")
                    {
                        if (diff2 != "1")
                            numerator = $"-{diff2}*{node.firstNode.get_expr()}";
                        else
                            numerator = $"-{node.firstNode.get_expr()}";
                    }

                    else if (diff1 != "0" && diff2 == "0")
                    {
                        if (diff1!="1")
                            numerator = $"{diff1}*{node.secondNode.get_expr()}";
                        else
                            numerator = $"{node.secondNode.get_expr()}";
                    }
                    else if (diff1 != "0" && diff2 != "0")
                    {
                        if (diff1 == "1" && diff2 != "1")
                            numerator = $"{node.secondNode.get_expr()}-{diff2}*{node.firstNode.get_expr()}";
                        else if (diff1 != "1" && diff2 == "1")
                            numerator = $"{diff1}*{node.secondNode.get_expr()}-{node.firstNode.get_expr()}";
                        else if (diff1 != "1" && diff2 !="1")
                            numerator = $"{diff1}*{node.secondNode.get_expr()}-{diff2}*{node.firstNode.get_expr()}";
                        else numerator = $"{node.secondNode.get_expr()}-{node.firstNode.get_expr()}";
                    }
                    return $"({numerator})/{node.secondNode.get_expr()}^2";
                case "sin":
                    diff1 = get_diff(node.firstNode);
                    if (diff1!="1")
                        return $"{diff1}*cos{node.firstNode.get_expr()}";
                    else
                        return $"cos{node.firstNode.get_expr()}";
                case "cos":
                    diff1 = get_diff(node.firstNode);
                    if (diff1!="1")
                        return $"{diff1}*-sin{node.firstNode.get_expr()}";
                    else
                        return $"-sin{node.firstNode.get_expr()}";
                case "~":
                    diff1 = get_diff(node.firstNode);
                    return $"-{diff1}";
                case "ln":
                    diff1 = get_diff(node.firstNode);
                    if (diff1 != "1")
                        return $"{diff1}*1/{node.firstNode.get_expr()}";
                    else
                        return $"1/{node.firstNode.get_expr()}";
                case null:
                    return "0";
                default:
                    return "0";

            }
               
        }

        public static string format_expr(string expr)
        {
            string pattern = @"(\(?-?\d+\)?|\d+)\*(\(?-?\d+\)?|\d+)";

            string result = Regex.Replace(expr, pattern, match =>
            {
                string part1 = match.Groups[1].Value;
                string part2 = match.Groups[2].Value;

                int num1 = int.Parse(part1.Replace("(", "").Replace(")", ""));
                int num2 = int.Parse(part2.Replace("(", "").Replace(")", ""));

                int product = num1 * num2;

                return product.ToString();
            });

            return result;
        }


        public bool check_mult(string expr)
        {
            for (int i = 0; i < expr.Length - 2; i++)
            {
                if (char.IsDigit(expr[i]) && (expr[i + 1] == '*' || (expr[i + 1] == '-' && expr[i + 2] == '*')) && char.IsDigit(expr[i + 2])) return true;
            }
            return false;
        }
    }

    public class Node
    {
        public Node firstNode = null;
        public Node secondNode = null;
        public string elem;
        protected List<string> operators;
        public Node(string elem)
        {
            operators = new List<string> { "+", "-", "(", "*", "/", "^", "sin", "cos", "~", "ln" };
            this.elem = elem;
        }
        
        public string get_expr()
        {
            string left;
            string right;
            if (firstNode != null && secondNode != null)
            {
                if (operators.Contains(firstNode.elem) && operators.Contains(secondNode.elem))
                {
                    left = firstNode.get_expr();
                    right = secondNode.get_expr();
                }
                else if (operators.Contains(firstNode.elem) && !operators.Contains(secondNode.elem))
                {
                    left = firstNode.get_expr();
                    right = secondNode.elem;
                }
                else if (!operators.Contains(firstNode.elem) && operators.Contains(secondNode.elem))
                {
                    left = firstNode.elem;
                    right = secondNode.get_expr();
                }
                else
                {
                    left = firstNode.elem;
                    right = secondNode.elem;
                }
                return $"({left}{elem}{right})";
            }
            else if (firstNode == null && secondNode != null)
                return $"({secondNode.elem})";
            else if (firstNode != null && secondNode == null)
                return $"({elem}{firstNode.get_expr()})";
            else return $"({elem})";
        }
        
       
        public void assign_links(Node secondNode, Node firstNode)
        {
            this.firstNode = firstNode;
            this.secondNode = secondNode;
        }
    }
}
