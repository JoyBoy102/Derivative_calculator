﻿using App;
using System;
using System.Linq;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Derivative diff;
        private string expr_str;
        private string pr_expr_str;
        public Form1()
        {
            InitializeComponent();
            chart1.Series["Series1"].BorderWidth = 4; 
            chart1.Series["Series2"].BorderWidth = 4;
            chart1.Series["Series3"].BorderWidth = 3; 
            chart1.ChartAreas["ChartArea1"].AxisX.MajorGrid.Enabled = false;
            chart1.ChartAreas["ChartArea1"].AxisY.MajorGrid.Enabled = false;
            chart1.Series["Series1"].IsXValueIndexed = false;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            diff = new Derivative(textBox1.Text);
            label1.Text = diff.diff;
            label1.Text = label1.Text.Replace("~", "-").Replace("--", "+");

            Expression expr = new Expression("0", 1);
            expr_str = textBox1.Text;
            pr_expr_str = label1.Text;
            double start = -10;
            double end = 10;
            if (expr_str.Contains("^(") || expr_str == "x^x")
            {
                string[] leftandright = expr_str.Split('^');
                if (leftandright[0].Contains("x") && leftandright[1].Contains("x"))
                    start = 0;
                else
                    start = -3.0;
                end = 3.0;
            }
            chart1.Series["Series1"].Points.Clear();
            chart1.Series["Series2"].Points.Clear();
            double range = expr_str.Contains("cos") || expr_str.Contains("sin") ? 0.01 : 0.2;

            for (double i = start; i <= end; i += range)
            {
                try
                {
                    string new_expr_str = expr_str.Replace("x", $"({i.ToString()})");
                    new_expr_str = new_expr_str.Replace("--", "").Replace("+-", "").Replace("-+", "-");
                    double y = double.Parse(expr.calculate(new_expr_str));
                    bool isEmp = isEmpty(new_expr_str);
                    if (!double.IsInfinity(y) && !double.IsNaN(y))
                    {
                        
                        chart1.Series["Series1"].Points.AddXY(i, y);
                    }
                    
                }
                catch
                {
                    continue;
                }
            }
        }

        private bool isEmpty(string expr)
        {
            Expression ex = new Expression("", 1);
            string[] expressions = expr.Split('/');
            string denominator = "";
            for (int i = expr.Length-1; i >= 0; i--)
            {
                if (expr[i] != '/') denominator += expr[i];
                else
                {
                    string denominator2 = new string(denominator.Reverse().ToArray());
                    string res = ex.calculate(denominator2);
                    if (res == "0") return false;
                    denominator += expr[i];
                }
                
            }
            return true;
            
        }


        private void Form1_Load(object sender, EventArgs e)
        {
            
        }
        private void chart1_MouseClick(object sender, MouseEventArgs e)
        {
            Chart chart = (Chart)sender;
            chart1.Series["Series2"].Points.Clear();
            HitTestResult hit = chart.HitTest(e.X, e.Y);

            if (hit.ChartElementType == ChartElementType.DataPoint && hit.Series == chart1.Series["Series1"])
            {
                Expression expr = new Expression("0", 1);
                Series series = hit.Series;
                DataPoint point = series.Points[hit.PointIndex];

                double k = double.Parse(expr.calculate(pr_expr_str.Replace("x", $"({point.XValue})")));
                double tangentRange = 2.0;
                double xMin = point.XValue - tangentRange;
                double xMax = point.XValue + tangentRange;
                
                for (double i = xMin; i <= xMax; i += 1)
                {
                    try
                    {
                        string tangent = $"{point.YValues[0]}+{k}*(x-{point.XValue})";
                        tangent = tangent.Replace("--", "+").Replace("+-", "-").Replace("-+","-");
                        label2.Text = tangent;
                        tangent = tangent.Replace("x", $"({i})");
                        double num = double.Parse(expr.calculate(tangent));
                        string new_expr_str = expr_str.Replace("x", $"{point.XValue}");
                        if (!double.IsInfinity(num) && !double.IsNaN(num) && isEmpty(new_expr_str))
                        {
                            // Добавляем точку на график
                            chart1.Series["Series2"].Points.AddXY(i, num);
                        }
                        
                    }
                    catch
                    {
                        continue;
                    }
                }

                MessageBox.Show(($"Вы нажали на точку: X: {point.XValue} Y:{point.YValues[0]}"));
            }
            
        }
        

    }
}
