﻿using System.Collections.Generic;
using System.Linq;
using System;

namespace App
{
    public class Expression
    {
        protected List<string> def_expr;
        public List<string> postfix_expr_ver1;

        public Dictionary<string, int> priorities = new Dictionary<string, int>
        {
            { "(", 0 },
            { "+", 1 },
            { "-", 1 },
            { "*", 2 },
            { "/", 2 },
            { "^", 3 },
            { "~", 1 },
            { "sin", 4 },
            { "cos", 4 },
            { "ln", 4 }
        };
        public Expression(string def_expr, int ver)
        {
            this.def_expr = get_formatted_expr(def_expr, ver);
            this.postfix_expr_ver1 = get_postfix_expression(this.def_expr);
        }

        private List<string> get_formatted_expr(string expr, int ver)
        {
            expr = expr.Replace('.', ',')
                       .Replace("-+", "-")
                       .Replace("--", "+")
                       .Replace("+-", "-");


            List<string> result = new List<string>();
            string num = "";
            format_minus(ref expr);
            for (int i = 0; i < expr.Length; i++)
            {

                if (!priorities.ContainsKey(expr[i].ToString()) && expr[i] != ')' && expr[i] != '~')
                {
                    num += expr[i];
                }
                else
                {
                    if (num != "")
                        result.Add(num);
                    result.Add(expr[i].ToString());
                    num = "";
                }
            }

            if (num != "") result.Add(num);

            return change_minuses(result);

        }

        private List<string> get_postfix_expression(List<string> formated_expr)
        {
            Stack<string> stack = new Stack<string>();
            List<string> result = new List<string>();
            bool isNum;
            foreach (string sym in formated_expr)
            {
                isNum = int.TryParse(sym, out int num) || double.TryParse(sym, out double num2);
                if ((sym != "sin" && sym != "cos" && sym != "ln") && (isNum || sym.All(x => char.IsLetter(x)))) result.Add(sym);
                else
                {
                    if (sym == "(") stack.Push(sym);
                    else if (sym == ")" && stack.Count != 0)
                    {
                        while (stack.Count > 0 && stack.Peek() != "(")
                            result.Add(stack.Pop());
                        stack.Pop();
                    }
                    else if (sym == "^")
                    {
                        while (stack.Count > 0 && (priorities[stack.Peek()] > priorities[sym]))
                            result.Add(stack.Pop());
                        stack.Push(sym);
                    }
                    else if (sym == "~")
                        stack.Push("~");

                    else if (priorities.ContainsKey(sym))
                    {
                        while (stack.Count > 0 && (priorities[stack.Peek()] >= priorities[sym]) && stack.Peek() != "(")
                            result.Add(stack.Pop());
                        stack.Push(sym);
                    }
                }
            }
            while (stack.Count > 0)
            {
                result.Add(stack.Pop());
            }
            return result;
        }

        public List<string> get_expr_postfix()
        {
            return postfix_expr_ver1;
        }

        public List<string> get_expr_def()
        {
            return def_expr;
        }
        public void format_minus(ref string expr)
        {
            
            while (expr.Contains("--"))
            {
                expr = expr.Replace("--", "+");
            }

        }



        private double choose_op(string elem1, string elem2, string op)
        {
            switch (op)
            {
                case "*":
                    return double.Parse(elem1) * double.Parse(elem2);
                case "/":
                    if (elem2 == "0") 
                        return 0;
                    return double.Parse(elem1) / double.Parse(elem2);
                case "+":
                    return double.Parse(elem1) + double.Parse(elem2);
                case "-":
                    return double.Parse(elem1) - double.Parse(elem2);
                case "^":
                    return Math.Pow(double.Parse(elem1), double.Parse(elem2));



                default: return 0;
            }
        }

        public List<string> change_minuses(List<string> expr)
        {
            List<string> expr_copy = new List<string>(expr);
            for (int i = 0; i < expr_copy.Count - 1; i++)
            {
                if (expr_copy[i] == "-" && i == 0)
                {

                    expr[i] = "~";


                }
                else if (priorities.ContainsKey(expr_copy[i]) && expr_copy[i + 1] == "-")
                {
                    /*
                    if (expr_copy[i + 2] != "(")
                    {
                        expr.Insert(i + 1, "(");
                        expr.Insert(i + 4, ")");
                    }
                    */
                    expr[i + 1] = "~";

                }


            }
            return expr;
        }

        public string calculate(string expr)
        {
            List<string> expr_formated = get_formatted_expr(expr,1);
            List<string> postfix_expr = get_postfix_expression(expr_formated);
            Stack<string> stack = new Stack<string>();
            foreach (string sym in postfix_expr)
            {
                if (double.TryParse(sym, out double num)) stack.Push(sym);
                else
                {
                    if (sym == "sin" || sym == "cos")
                    {
                        double angleInRadians = double.Parse(stack.Pop());
                        if (sym == "sin")
                            stack.Push(Math.Sin(angleInRadians).ToString());
                        else
                            stack.Push(Math.Cos(angleInRadians).ToString());
                    }
                    else if (sym == "~")
                        stack.Push((double.Parse(stack.Pop()) * -1).ToString());
                    else if (sym == "ln")
                    {
                        double num2 = double.Parse(stack.Pop());
                        if (num2 != 0)
                            stack.Push(Math.Log(num2).ToString());
                        else
                            stack.Push("0");
                    }
                    else if (sym == "e")
                        stack.Push(Math.E.ToString());
                    else
                    {
                        string elem2 = stack.Pop();
                        string elem1 = stack.Pop();
                        stack.Push(choose_op(elem1, elem2, sym).ToString());
                    }
                }
            }
            return stack.Peek();
        }

    }

}